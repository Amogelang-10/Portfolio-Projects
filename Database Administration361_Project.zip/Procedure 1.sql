CREATE PROCEDURE dbo.spMacyOrders_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT OrderID, CustomerID, OrderDate, TotalAmount, Status
    FROM Macy.vOrders;
END;
GO