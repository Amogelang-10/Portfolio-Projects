CREATE PROCEDURE dbo.spMp_Menu
AS
BEGIN
    SET NOCOUNT ON;

    SELECT MenuItemID, Description, Price
    FROM Mp.Menu;
END;
GO