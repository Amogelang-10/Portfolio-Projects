
CREATE DATABASE MacyPizzaDB
ON PRIMARY 
(
    NAME = MacyPizzaPrimary,
    FILENAME = 'C:\Users\NJvan\Documents\Belgium Campus\DBA 361\Project\MacyPizzaPrimary.mdf',
    SIZE = 10MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 5MB
),
FILEGROUP Secondary 
(
    NAME = MacyPizzaSecondary,
    FILENAME = 'C:\Users\NJvan\Documents\Belgium Campus\DBA 361\Project\MacyPizzaSecondary.mdf',
    SIZE = 10MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 5MB
)
LOG ON 
(
    NAME = MacyPizzaLog,
    FILENAME = 'C:\Users\NJvan\Documents\Belgium Campus\DBA 361\Project\MacyPizzaLog.ldf',
    SIZE = 10MB,
    MAXSIZE = 100MB,
    FILEGROWTH = 5MB
);
GO

ALTER DATABASE MacyPizzaDB SET RECOVERY FULL;

GO

ALTER DATABASE MacyPizzaDB SET AUTO_SHRINK ON;