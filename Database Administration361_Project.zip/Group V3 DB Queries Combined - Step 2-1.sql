USE master;
GO

CREATE LOGIN Alice WITH PASSWORD = 'Alice123';
CREATE LOGIN Charlie WITH PASSWORD = 'Charlie123';
CREATE LOGIN Dana WITH PASSWORD = 'Dana123';
CREATE LOGIN Bob WITH PASSWORD = 'BobJob';
CREATE LOGIN Eve WITH PASSWORD = 'EveAdam';
CREATE LOGIN Frank WITH PASSWORD = 'FrankCastle';
CREATE LOGIN Grace WITH PASSWORD = 'Gracing';
CREATE LOGIN Hank WITH PASSWORD = 'HankSpank';
CREATE LOGIN Ivy WITH PASSWORD = 'IvyLively';
CREATE LOGIN Jack WITH PASSWORD = 'JackWackCrack';
CREATE LOGIN Karen WITH PASSWORD = 'Karen';
GO


USE MacyPizzaDB;
GO


CREATE SCHEMA Macy;
GO


CREATE TABLE Macy.Users
(
    UserID INT IDENTITY (1,1) PRIMARY KEY,
    UserName NVARCHAR(50) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Role NVARCHAR(20) NOT NULL CHECK (Role IN ('Management','Staff','Customer')),
    RegDate DATETIME DEFAULT GETDATE()
)
ON [PRIMARY];
GO


CREATE TABLE Macy.Customers
(
    CustomerID INT IDENTITY (1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50),
    Email NVARCHAR(100) UNIQUE NOT NULL,
    Phone NVARCHAR(15),
    Address NVARCHAR(255),
    UserID INT FOREIGN KEY REFERENCES Macy.Users(UserID)
)
ON Secondary;
GO


CREATE TABLE Macy.Menu
(
    MenuItemID INT IDENTITY (1,1) PRIMARY KEY,
    ItemName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(255),
    Price DECIMAL(10,2) NOT NULL CHECK (Price > 0),
    IsAvailable BIT DEFAULT 1
)
ON Secondary;
GO


CREATE TABLE Macy.Orders
(
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL FOREIGN KEY REFERENCES Macy.Customers(CustomerID),
    OrderDate DATETIME DEFAULT GETDATE(),
    TotalAmount DECIMAL(10,2) CHECK (TotalAmount >= 0),
    Status NVARCHAR(20) DEFAULT 'Pending' CHECK (Status IN ('Pending', 'CoMacyleted', 'Cancelled'))
)
ON Secondary;
GO


CREATE TABLE Macy.OrderItems
(
    OrderItemID INT IDENTITY (1,1) PRIMARY KEY,
    OrderID INT NOT NULL FOREIGN KEY REFERENCES Macy.Orders(OrderID),
    MenuItemID INT NOT NULL FOREIGN KEY REFERENCES Macy.Menu(MenuItemID),
    Quantity INT NOT NULL CHECK (Quantity > 0),
    Price DECIMAL(10,2) NOT NULL,
    Subtotal AS (Quantity * Price) PERSISTED
)
ON Secondary;
GO

-- Verification: List Tables in Schema 'Macy'
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'Macy';
GO


-- Create Database Users and Assign Roles/Permissions
USE MacyPizzaDB;
GO

-- Create Users mapped to the logins
CREATE USER Alice FOR LOGIN Alice;
CREATE USER Charlie FOR LOGIN Charlie;
CREATE USER Dana FOR LOGIN Dana;
CREATE USER Bob FOR LOGIN Bob;
CREATE USER Eve FOR LOGIN Eve;
CREATE USER Frank FOR LOGIN Frank;
CREATE USER Grace FOR LOGIN Grace;
CREATE USER Hank FOR LOGIN Hank;
CREATE USER Ivy FOR LOGIN Ivy;
CREATE USER Jack FOR LOGIN Jack;
CREATE USER Karen FOR LOGIN Karen;
GO

-- Create the Management Role and Grant Permissions on Macy tables
CREATE ROLE Management;
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.Users TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.Customers TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.Menu TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.Orders TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.OrderItems TO Management;
GO

-- Assign users to the Management Role
EXEC sp_addrolemember 'Management', 'Alice';
EXEC sp_addrolemember 'Management', 'Charlie';
EXEC sp_addrolemember 'Management', 'Dana';
GO

-- Create the Staff Role and Grant Permissions on Macy tables
CREATE ROLE Staff;
GO

GRANT SELECT, INSERT, UPDATE ON Macy.Customers TO Staff;
GRANT SELECT ON Macy.Menu TO Staff;
GRANT SELECT, INSERT, UPDATE ON Macy.Orders TO Staff;
GRANT SELECT, INSERT, UPDATE ON Macy.OrderItems TO Staff;
GO

-- Assign users to the Staff Role
EXEC sp_addrolemember 'Staff', 'Bob';
EXEC sp_addrolemember 'Staff', 'Eve';
EXEC sp_addrolemember 'Staff', 'Frank';
EXEC sp_addrolemember 'Staff', 'Grace';
EXEC sp_addrolemember 'Staff', 'Hank';
EXEC sp_addrolemember 'Staff', 'Ivy';
EXEC sp_addrolemember 'Staff', 'Jack';
EXEC sp_addrolemember 'Staff', 'Karen';
GO

USE MacyPizzaDB;
GO

-- Create Schema 'Macy'
CREATE SCHEMA Macy;
GO

-- Create View: vUsers
CREATE VIEW Macy.vUsers AS
SELECT UserID, UserName, Role, RegDate
FROM Macy.Users;
GO

-- Create View: vCustomers
CREATE VIEW Macy.vCustomers AS
SELECT CustomerID, FirstName, LastName, Email, Phone, Address, UserID
FROM Macy.Customers;
GO

-- Create View: vMenu
CREATE VIEW Macy.vMenu AS
SELECT MenuItemID, ItemName, Description, Price, IsAvailable
FROM Macy.Menu;
GO

-- Create View: vOrders
CREATE VIEW Macy.vOrders AS
SELECT OrderID, CustomerID, OrderDate, TotalAmount, Status
FROM Macy.Orders;
GO

-- Create View: vOrderItems
CREATE VIEW Macy.vOrderItems AS
SELECT OrderItemID, OrderID, MenuItemID, Quantity, Price, Subtotal
FROM Macy.OrderItems;
GO

-- Grant unrestricted access to all views for Management role
GRANT SELECT, INSERT, UPDATE, DELETE ON OBJECT::Macy.vUsers TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON OBJECT::Macy.vCustomers TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON OBJECT::Macy.vMenu TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON OBJECT::Macy.vOrders TO Management;
GRANT SELECT, INSERT, UPDATE, DELETE ON OBJECT::Macy.vOrderItems TO Management;
GO

-- Additionally, grant read and write access (SELECT, INSERT, UPDATE) on views except Users
GRANT SELECT, INSERT, UPDATE ON OBJECT::Macy.vCustomers TO Management;
GRANT SELECT, INSERT, UPDATE ON OBJECT::Macy.vMenu TO Management;
GRANT SELECT, INSERT, UPDATE ON OBJECT::Macy.vOrders TO Management;
GRANT SELECT, INSERT, UPDATE ON OBJECT::Macy.vOrderItems TO Management;
GO

-- Full Backup
USE master;
GO
BACKUP DATABASE MacyPizzaDB
TO DISK = 'C:\Users\NJvan\Documents\Belgium Campus\DBA 361\Project\MacyPizzaDB_Full.bak'
WITH FORMAT,
NAME = 'Full Backup of MacyPizzaDB';
GO

-- Differential Backup
USE master;
GO
BACKUP DATABASE MacyPizzaDB
TO DISK = 'C:\Users\NJvan\Documents\Belgium Campus\DBA 361\Project\MacyPizzaDB_Diff.bak'
WITH DIFFERENTIAL,
NAME = 'Differential Backup of MacyPizzaDB';
GO

-- Filegroup Backup (Secondary filegroup)
USE master;
GO
BACKUP DATABASE MacyPizzaDB
FILEGROUP = 'Secondary'
TO DISK = 'C:\Users\NJvan\Documents\Belgium Campus\DBA 361\Project\MacyPizzaDB_SecondaryFilegroup.bak'
WITH FORMAT,
NAME = 'Filegroup Backup of Secondary Filegroup in MacyPizzaDB';
GO
