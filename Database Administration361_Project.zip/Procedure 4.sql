USE MacyPizzaDB;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE PROCEDURE dbo.spMacyCustomers_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT CustomerID, FirstName, LastName, Phone, Email, Address
    FROM Macy.vCustomers;
END;
GO
