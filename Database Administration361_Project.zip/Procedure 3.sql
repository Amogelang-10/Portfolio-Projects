CREATE PROCEDURE dbo.spMacyOrdersItems_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT OrderItemID, Price, Quantity, MenuItemID
    FROM Macy.vOrderItems;
END;
GO