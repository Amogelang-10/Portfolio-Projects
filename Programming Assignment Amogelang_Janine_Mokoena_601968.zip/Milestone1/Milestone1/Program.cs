﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone1
{
    internal class Program
    {
        enum Menu
        {
            CaptureDetails = 1,
            CheckDiscountQualification,
            ShowQualificationStats,
            ExitProgram
        }

        static List<string> names = new List<string>();
        static List<bool> isResidence = new List<bool>();
        static List<int> yearsCampus = new List<int>();
        static List<int> yearsResidence = new List<int>();
        static List<double> allowance = new List<double>();
        static List<double> marks = new List<double>();

        static List<string> qualifiedStudents = new List<string>();
        static int granted = 0;
        static int denied = 0;

        static void Main(string[] args)
        {
            bool running = true;

            while (running)
            {
                Console.Clear();
                Console.WriteLine("BELGIUM CAMPUS DISCOUNT QUALIFICATION SYSTEM");
                Console.WriteLine("1. Capture Student Details");
                Console.WriteLine("2. Check Discount Qualification");
                Console.WriteLine("3. Show Qualification Statistics");
                Console.WriteLine("4. Exit Program");
                Console.Write("Enter your choice (1-4): ");
                string input = Console.ReadLine();

                int option;
                if (int.TryParse(input, out option))
                {
                    if (option == (int)Menu.CaptureDetails)
                    {
                        CaptureDetails();
                    }
                    else if (option == (int)Menu.CheckDiscountQualification)
                    {
                        CheckQualification();
                    }
                    else if (option == (int)Menu.ShowQualificationStats)
                    {
                        ShowStats();
                    }
                    else if (option == (int)Menu.ExitProgram)
                    {
                        Console.WriteLine("Goodbye!");
                        running = false;
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice. Press Enter to continue.");
                        Console.ReadLine();
                    }
                }
                else
                {
                    Console.WriteLine("Please enter a valid number.");
                    Console.ReadLine();
                }
            }
        }

        static void CaptureDetails()
        {
            bool adding = true;
            while (adding)
            {
                Console.Clear();
                Console.WriteLine("CAPTURE STUDENT DETAILS");

                Console.Write("Enter full name: ");
                names.Add(Console.ReadLine());

                Console.Write("Is residence student? (true/false): ");
                bool res = bool.Parse(Console.ReadLine());
                isResidence.Add(res);

                Console.Write("Years on campus: ");
                int yCampus = int.Parse(Console.ReadLine());
                yearsCampus.Add(yCampus);

                Console.Write("Years at current residence: ");
                int yRes = int.Parse(Console.ReadLine());
                yearsResidence.Add(yRes);

                Console.Write("Monthly allowance: ");
                double sal = double.Parse(Console.ReadLine());
               allowance.Add(sal);

                Console.Write("Average mark (%): ");
                double mark = double.Parse(Console.ReadLine());
                marks.Add(mark);

                Console.Write("Add another student? (Y/N): ");
                string again = Console.ReadLine();
                if (again.ToUpper() != "Y")
                {
                    adding = false;
                }
            }
        }

        static void CheckQualification()
        {
            Console.Clear();
            Console.WriteLine("CHECK DISCOUNT QUALIFICATION");

            if (names.Count == 0)
            {
                Console.WriteLine("No student data. Please capture details first.");
                Console.ReadLine();
                return;
            }

            qualifiedStudents.Clear();
            granted = 0;
            denied = 0;

            for (int i = 0; i < names.Count; i++)
            {
                if (isResidence[i])
                {
                    if (yearsCampus[i] > 1)
                    {
                        if (marks[i] > 85)
                        {
                            if (allowance[i] <= 1000)
                            {
                                Console.WriteLine($"{names[i]} QUALIFIES for the discount.");
                                granted++;
                                qualifiedStudents.Add(names[i]);
                                continue;
                            }
                        }
                    }
                }

                Console.WriteLine($"{names[i]} DOES NOT qualify for the discount.");
                denied++;
            }

            Console.WriteLine("Check complete. Press Enter to continue.");
            Console.ReadLine();
        }

        static void ShowStats()
        {
            Console.Clear();
            Console.WriteLine("DISCOUNT QUALIFICATION STATISTICS");

            Console.WriteLine($"Total students: {names.Count}");
            Console.WriteLine($"Granted: {granted}");
            Console.WriteLine($"Denied: {denied}");

            if (qualifiedStudents.Count > 0)
            {
                Console.WriteLine("Qualified Students:");
                foreach (string name in qualifiedStudents)
                {
                    Console.WriteLine("- " + name);
                }
            }
            else
            {
                Console.WriteLine("No students currently qualify.");
            }

            Console.WriteLine("Press Enter to return to menu.");
            Console.ReadLine();
        }
    }
    }
